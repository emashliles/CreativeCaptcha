﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CreativeCaptcha.WebApi
{
    public class AddBasicConfirmationResponse
    {
        public bool Success { get; set; }
    }
}
