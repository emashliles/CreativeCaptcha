﻿using CreativeCaptcha.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CreativeCaptcha.WebApi
{
    public class ValidateBasicResponse
    {
        public bool IsHuman { get; set; }


    }
}
